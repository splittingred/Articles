--------------------
Snippet: getResources
--------------------
Version: 1.6.0-pl
Released: December 30, 2013
Since: December 28, 2009
Author: Jason Coward <jason@opengeek.com>

A general purpose Resource listing and summarization snippet for MODX Revolution.

Official Documentation:
http://docs.modxcms.com/display/ADDON/getResources
